export interface IconProps {
  size?: number | string;
  color?: string;
}
